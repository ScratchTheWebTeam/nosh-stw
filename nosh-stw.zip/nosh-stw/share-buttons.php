<div class="shbutton">
                            <div class="share-buttons-container">
                              <span class="share-msg"><?php esc_html_e('Share:', 'nosh-stw'); ?></span>
                              <ul aria-hidden="true" aria-label="<?php esc_attr_e('Share', 'nosh-stw'); ?>" class="share-buttons" role="menu">
<li>
<div class="shicon" onclick="window.open(&#39;https://www.facebook.com/sharer/sharer.php?u=&#39;+encodeURIComponent(location.href),&#39;facebook-share-dialog&#39;,&#39;width=626,height=436&#39;);return false;">
<span aria-label="<?php esc_attr_e('Share to Facebook', 'nosh-stw'); ?>" class="sharing-platform-button sharing-element-facebook" role="menuitem">
<svg class="svg-icon-24 sharing-facebook" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
<path d="M20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-1 2v3h-2c-.5 0-1 .4-1 1v2h3v3h-3v7h-3v-7h-2v-3h2V7.5C13 5.6 14.6 4 16.5 4H19z"></path>
</svg>
</span>
</div>
</li>
<li>
<div class="shicon" onclick="window.open(&#39;https://twitter.com/share?url=&#39;+encodeURIComponent(location.href));return false;">
<span aria-label="<?php esc_attr_e('Share to Twitter', 'nosh-stw'); ?>" class="sharing-platform-button sharing-element-twitter" role="menuitem">
<svg class="svg-icon-24 sharing-twitter" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
<path d="M20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2.3 7.3c-.1 4.6-3 7.8-7.4 8-1.8.1-3.1-.5-4.3-1.2 1.3.2 3-.3 3.9-1.1-1.3-.1-2.1-.8-2.5-1.9.4.1.8.1 1.1 0-1.2-.4-2-1.1-2.1-2.7.3.2.7.3 1.1.3-.9-.5-1.6-2.3-.8-3.6C8 8.5 9.6 9.7 12.2 9.9c-.6-2.8 3.1-4.3 4.6-2.4.7-.1 1.2-.4 1.7-.7-.2.7-.6 1.1-1.1 1.5.5-.1 1-.2 1.4-.4 0 .5-.6 1-1.1 1.4z"></path>
</svg>
</span>
</div>
</li>
<li>
<div class="shicon" onclick="window.open(&#39;https://pinterest.com/pin/create/link/?url=&#39;+encodeURIComponent(location.href));return false;">
<span aria-label="<?php esc_attr_e('Share to Pinterest', 'nosh-stw'); ?>" class="sharing-platform-button sharing-element-pinterest" role="menuitem">
<svg class="svg-icon-24 sharing-pinterest" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
<path d="M20 2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 14.2c-.8 0-1.6-.3-2.1-.9l-.9 3.2-.1.2c-.2.3-.5.5-.9.5-.6 0-1.1-.5-1.1-1.1V17.8l1.8-5.6c-9.6-12.2-.2-.6-.2-1.5 0-1.7.9-2.2 1.7-2.2s1.4.3 1.4 1.3c0 1.3-.9 2-.9 3 0 .7.6 1.3 1.3 1.3 2.3 0 3.2-1.8 3.2-3.4 0-2.2-1.9-3.9-4.2-3.9s-4.2 1.8-4.2 3.9c0 .7.2 1.3.5 1.9.1.2.1.3.1.5 0 .6-.4 1-1 1-.4 0-.7-.2-.9-.5-.5-.9-.8-1.9-.8-3 0-3.3 2.8-5.9 6.2-5.9s6.2 2.7 6.2 5.9c.1 2.8-1.5 5.6-5.1 5.6z"></path>
</svg>
</span>
</a>
</li>
</ul>
                            </div>
                          </div>