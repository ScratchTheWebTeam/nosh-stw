<?php if(is_active_sidebar('stw_nosh_sidebar')): ?>
<aside class="sidebar-container col-lg-4 col-md-12" role="complementary">
<?php

    dynamic_sidebar('stw_nosh_sidebar');

?>
</aside>
<?php endif; ?>